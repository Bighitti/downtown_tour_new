package it.unicam.ids.dciotti.downtowntour.mapper;

import it.unicam.ids.dciotti.downtowntour.entity.TouristEntity;
import it.unicam.ids.dciotti.downtowntour.model.Coordinates;
import it.unicam.ids.dciotti.downtowntour.model.TouristAuth;
import it.unicam.ids.dciotti.downtowntour.dto.TouristDTO;
import it.unicam.ids.dciotti.downtowntour.model.User;
import org.springframework.stereotype.Service;

@Service
public class TouristMapper {

    public TouristDTO dto(TouristAuth model) {
        if(model == null) return null;
        TouristDTO touristDTO = new TouristDTO();
        touristDTO.setFirstName(model.getFirstName());
        touristDTO.setLastName(model.getLastName());
        touristDTO.setBirthday(model.getBirthday());
        touristDTO.setEmail(model.getEmail());
        touristDTO.setPhone(model.getPhone());
        return touristDTO;
    }

    public TouristAuth modelFromDto(TouristDTO dto) {
        if(dto == null) return null;
        TouristAuth tourist = new TouristAuth(dto.get);
        tourist.setFirstName(dto.getFirstName());
        tourist.setLastName(dto.getLastName());
        tourist.setBirthday(dto.getBirthday());
        tourist.setEmail(dto.getEmail());
        tourist.setPhone(dto.getPhone());
        return tourist;
    }

    public TouristAuth modelFromEntity(TouristEntity entity) {
        if(entity == null) return null;
        Coordinates coords = new Coordinates(entity.getLastCoordX(), entity.getLastCoordY());
        TouristAuth tourist = new TouristAuth(coords);
        tourist.setFirstName(entity.getFirstname());
        tourist.setLastName(entity.getLastname());
        tourist.setBirthday(entity.getBirthday());
        tourist.setEmail(entity.getEmail());
        tourist.setPhone(entity.getPhone());
        return tourist;
    }

    public TouristEntity entity(TouristAuth model) {
        if (model == null) return null;
        TouristEntity touristEntity = new TouristEntity();
        touristEntity.setFirstname(model.getFirstName());
        touristEntity.setLastname(model.getLastName());
        touristEntity.setBirthday(model.getBirthday());
        touristEntity.setEmail(model.getEmail());
        touristEntity.setPhone(model.getPhone());
        return touristEntity;
    }
}